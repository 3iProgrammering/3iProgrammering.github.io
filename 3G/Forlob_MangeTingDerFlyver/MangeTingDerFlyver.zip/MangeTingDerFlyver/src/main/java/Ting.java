import processing.core.PApplet;

public class Ting {


    //Tings position
    float x, y;
    float colorR = 100;

    Ting(float inputX, float inputY){

        //Opgave 2: Her skal du skrive kode der sætter positionen for tingen x og y

    }

    void tegn(){
        //Opgave 3: Her skal du skrive kode der tegner denne "Ting"

    }

    void flyv(){
        //Opgave 4: Her skal du skrive kode der flytter "Ting"
        //ps: Husk de må ikke flytte sig uden for skærmen...


    }




}
